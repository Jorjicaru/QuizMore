export interface TerritoryDef {
  id: string;
  name: string;
  shortName: string;
  region: string;
  labelX: number;
  labelY: number;
  polygon: string;
  neighbors: string[];
}

/**
 * 10 Teritorii Istorice ale României (pentru meciuri în 2 jucători)
 * Câte 5 teritorii potențiale per jucător (1 bază + 4 cuceriri).
 */
export const ROMANIA_10_TERRITORIES: TerritoryDef[] = [
  {
    id: 'maramures_crisana',
    name: 'Maramureș & Crișana',
    shortName: 'MM-CR',
    region: 'Nord-Vest',
    labelX: 180,
    labelY: 150,
    polygon: '90,215 160,95 240,45 340,35 360,90 310,125 210,120 195,185 185,245 90,215',
    neighbors: ['banat', 'transilvania_nord', 'bucovina'],
  },
  {
    id: 'bucovina',
    name: 'Bucovina & Botoșani',
    shortName: 'SV-BT',
    region: 'Nord-Est',
    labelX: 430,
    labelY: 70,
    polygon: '340,35 440,45 530,65 520,130 435,145 360,90 340,35',
    neighbors: ['maramures_crisana', 'transilvania_nord', 'moldova'],
  },
  {
    id: 'transilvania_nord',
    name: 'Transilvania de Nord (Cluj & Mureș)',
    shortName: 'CJ-MS',
    region: 'Transilvania',
    labelX: 300,
    labelY: 165,
    polygon: '210,120 310,125 360,90 435,145 450,195 440,215 380,255 295,215 215,200 195,185 210,120',
    neighbors: ['maramures_crisana', 'bucovina', 'moldova', 'transilvania_sud'],
  },
  {
    id: 'moldova',
    name: 'Moldova (Iași, Bacău & Galați)',
    shortName: 'IS-BC',
    region: 'Moldova',
    labelX: 535,
    labelY: 200,
    polygon: '530,65 570,110 605,185 625,260 560,320 470,265 450,195 435,145 520,130 530,65',
    neighbors: ['bucovina', 'transilvania_nord', 'transilvania_sud', 'dunarea_baragan'],
  },
  {
    id: 'banat',
    name: 'Banat (Timiș & Caraș-Severin)',
    shortName: 'TM-CS',
    region: 'Vest',
    labelX: 120,
    labelY: 330,
    polygon: '90,215 185,245 195,305 185,385 145,440 120,395 85,340 70,275 90,215',
    neighbors: ['maramures_crisana', 'transilvania_sud', 'oltenia'],
  },
  {
    id: 'transilvania_sud',
    name: 'Transilvania de Sud (Sibiu & Brașov)',
    shortName: 'SB-BV',
    region: 'Transilvania',
    labelX: 310,
    labelY: 260,
    polygon: '215,200 295,215 380,255 440,215 450,195 470,265 435,315 375,310 290,315 215,320 195,305 185,245 215,200',
    neighbors: ['maramures_crisana', 'banat', 'transilvania_nord', 'moldova', 'oltenia', 'muntenia_nord'],
  },
  {
    id: 'oltenia',
    name: 'Oltenia (Craiova, Gorj & Mehedinți)',
    shortName: 'DJ-GJ',
    region: 'Sud-Vest',
    labelX: 220,
    labelY: 420,
    polygon: '195,305 215,320 290,315 320,380 255,415 275,470 275,520 215,510 170,475 145,440 185,385 195,305',
    neighbors: ['banat', 'transilvania_sud', 'muntenia_nord', 'muntenia_sud'],
  },
  {
    id: 'muntenia_nord',
    name: 'Muntenia de Nord (Argeș & Prahova)',
    shortName: 'AG-PH',
    region: 'Muntenia',
    labelX: 365,
    labelY: 360,
    polygon: '290,315 375,310 435,315 440,395 350,410 320,380 290,315',
    neighbors: ['transilvania_sud', 'oltenia', 'muntenia_sud', 'dunarea_baragan'],
  },
  {
    id: 'muntenia_sud',
    name: 'Muntenia de Sud (Teleorman & Olt)',
    shortName: 'TR-OT',
    region: 'Muntenia',
    labelX: 340,
    labelY: 470,
    polygon: '255,415 320,380 350,410 425,435 385,545 335,535 275,520 275,470 255,415',
    neighbors: ['oltenia', 'muntenia_nord', 'dunarea_baragan'],
  },
  {
    id: 'dunarea_baragan',
    name: 'București, Bărăgan & Dobrogea',
    shortName: 'B-CT',
    region: 'Sud-Est',
    labelX: 570,
    labelY: 410,
    polygon: '435,315 470,265 560,320 625,260 670,305 735,335 715,390 685,460 670,520 575,495 520,515 425,435 350,410 440,395 435,315',
    neighbors: ['moldova', 'muntenia_nord', 'muntenia_sud'],
  },
];

/**
 * 15 Teritorii Clasice Conquiztador (pentru 3 jucători - meciul standard de referință)
 */
export const ROMANIA_15_TERRITORIES: TerritoryDef[] = [
  // 1. Maramureș & Satu Mare (Nord)
  {
    id: 'maramures',
    name: 'Maramureș & Satu Mare',
    shortName: 'MM',
    region: 'Nord',
    labelX: 250,
    labelY: 75,
    polygon: '160,95 240,45 340,35 360,90 310,125 210,120 160,95',
    neighbors: ['crisana', 'transilvania_nord', 'bucovina'],
  },
  // 2. Bucovina (Suceava & Botoșani)
  {
    id: 'bucovina',
    name: 'Bucovina & Botoșani',
    shortName: 'SV',
    region: 'Nord-Est',
    labelX: 430,
    labelY: 70,
    polygon: '340,35 440,45 530,65 520,130 435,145 360,90 340,35',
    neighbors: ['maramures', 'transilvania_nord', 'moldova_nord'],
  },
  // 3. Moldova de Nord (Iași & Neamț)
  {
    id: 'moldova_nord',
    name: 'Moldova de Nord (Iași & Neamț)',
    shortName: 'IS',
    region: 'Moldova',
    labelX: 515,
    labelY: 155,
    polygon: '530,65 570,110 605,185 525,215 450,195 435,145 520,130 530,65',
    neighbors: ['bucovina', 'transilvania_nord', 'transilvania_sud', 'moldova_sud'],
  },
  // 4. Crișana (Bihor & Arad)
  {
    id: 'crisana',
    name: 'Crișana (Oradea & Arad)',
    shortName: 'CR',
    region: 'Vest',
    labelX: 130,
    labelY: 185,
    polygon: '160,95 210,120 195,185 185,245 90,215 110,155 160,95',
    neighbors: ['maramures', 'transilvania_nord', 'banat', 'transilvania_sud'],
  },
  // 5. Transilvania de Nord (Cluj, Bistrița & Sălaj)
  {
    id: 'transilvania_nord',
    name: 'Transilvania de Nord (Cluj)',
    shortName: 'CJ',
    region: 'Transilvania',
    labelX: 285,
    labelY: 160,
    polygon: '210,120 310,125 360,90 435,145 450,195 380,210 295,215 215,200 195,185 210,120',
    neighbors: ['maramures', 'bucovina', 'crisana', 'transilvania_sud', 'moldova_nord'],
  },
  // 6. Banat (Timișoara & Caraș-Severin)
  {
    id: 'banat',
    name: 'Banat (Timiș & Caraș)',
    shortName: 'TM',
    region: 'Sud-Vest',
    labelX: 115,
    labelY: 335,
    polygon: '90,215 185,245 195,305 185,385 145,440 120,395 85,340 70,275 90,215',
    neighbors: ['crisana', 'transilvania_sud', 'oltenia_nord', 'oltenia_sud'],
  },
  // 7. Transilvania de Sud (Sibiu, Brașov & Mureș)
  {
    id: 'transilvania_sud',
    name: 'Transilvania de Sud (Sibiu & Brașov)',
    shortName: 'BV',
    region: 'Transilvania',
    labelX: 310,
    labelY: 260,
    polygon: '215,200 295,215 380,210 450,195 470,265 435,315 375,310 290,315 215,320 195,305 185,245 215,200',
    neighbors: ['crisana', 'transilvania_nord', 'moldova_nord', 'moldova_sud', 'banat', 'oltenia_nord', 'muntenia_nord'],
  },
  // 8. Moldova de Sud (Bacău, Vaslui & Vrancea)
  {
    id: 'moldova_sud',
    name: 'Moldova de Sud (Bacău & Vrancea)',
    shortName: 'BC',
    region: 'Moldova',
    labelX: 525,
    labelY: 255,
    polygon: '450,195 525,215 605,185 625,260 560,320 470,265 450,195',
    neighbors: ['moldova_nord', 'transilvania_sud', 'dunarea_de_jos', 'baragan'],
  },
  // 9. Oltenia de Nord (Gorj & Vâlcea)
  {
    id: 'oltenia_nord',
    name: 'Oltenia de Nord (Gorj & Vâlcea)',
    shortName: 'GJ',
    region: 'Oltenia',
    labelX: 255,
    labelY: 370,
    polygon: '195,305 215,320 290,315 320,380 255,415 185,385 195,305',
    neighbors: ['banat', 'transilvania_sud', 'muntenia_nord', 'oltenia_sud'],
  },
  // 10. Oltenia de Sud (Dolj & Mehedinți)
  {
    id: 'oltenia_sud',
    name: 'Oltenia de Sud (Craiova & Mehedinți)',
    shortName: 'DJ',
    region: 'Oltenia',
    labelX: 205,
    labelY: 465,
    polygon: '185,385 255,415 275,470 275,520 215,510 170,475 145,440 185,385',
    neighbors: ['banat', 'oltenia_nord', 'muntenia_sud'],
  },
  // 11. Muntenia de Nord (Argeș & Prahova)
  {
    id: 'muntenia_nord',
    name: 'Muntenia de Nord (Prahova & Argeș)',
    shortName: 'PH',
    region: 'Muntenia',
    labelX: 375,
    labelY: 360,
    polygon: '290,315 375,310 435,315 440,395 350,410 320,380 290,315',
    neighbors: ['transilvania_sud', 'oltenia_nord', 'muntenia_sud', 'baragan'],
  },
  // 12. Muntenia de Sud (Teleorman & Olt)
  {
    id: 'muntenia_sud',
    name: 'Muntenia de Sud (Dunăre & Olt)',
    shortName: 'TR',
    region: 'Muntenia',
    labelX: 335,
    labelY: 470,
    polygon: '255,415 320,380 350,410 425,435 385,545 335,535 275,520 275,470 255,415',
    neighbors: ['oltenia_nord', 'oltenia_sud', 'muntenia_nord', 'baragan'],
  },
  // 13. Bărăgan (București & Ialomița)
  {
    id: 'baragan',
    name: 'București & Bărăgan',
    shortName: 'B',
    region: 'Muntenia de Est',
    labelX: 485,
    labelY: 415,
    polygon: '435,315 470,265 560,320 575,380 575,495 520,515 425,435 350,410 440,395 435,315',
    neighbors: ['transilvania_sud', 'moldova_sud', 'muntenia_nord', 'muntenia_sud', 'dunarea_de_jos', 'dobrogea'],
  },
  // 14. Dunărea de Jos (Galați & Brăila)
  {
    id: 'dunarea_de_jos',
    name: 'Dunărea de Jos (Galați & Brăila)',
    shortName: 'GL',
    region: 'Sud-Est',
    labelX: 595,
    labelY: 310,
    polygon: '560,320 625,260 640,310 670,305 605,375 575,380 560,320',
    neighbors: ['moldova_sud', 'baragan', 'dobrogea'],
  },
  // 15. Dobrogea (Constanța & Tulcea / Delta)
  {
    id: 'dobrogea',
    name: 'Dobrogea (Constanța & Delta)',
    shortName: 'CT',
    region: 'Dobrogea',
    labelX: 665,
    labelY: 415,
    polygon: '670,305 735,335 715,390 685,460 670,520 575,495 575,380 605,375 670,305',
    neighbors: ['dunarea_de_jos', 'baragan'],
  },
];

/**
 * 25 teritorii (4–5 jucători). Geometria actuală este o schiță SVG,
 * nu o hartă administrativă GeoJSON exactă.
 */
export const ROMANIA_25_TERRITORIES: TerritoryDef[] = [
  // Nord
  {
    id: 'satu_mare',
    name: 'Satu Mare',
    shortName: 'SM',
    region: 'Nord-Vest',
    labelX: 200,
    labelY: 75,
    polygon: '160,95 240,45 270,70 210,120 160,95',
    neighbors: ['maramures', 'bihor', 'salaj'],
  },
  {
    id: 'maramures',
    name: 'Maramureș (Baia Mare)',
    shortName: 'MM',
    region: 'Nord',
    labelX: 295,
    labelY: 75,
    polygon: '240,45 340,35 360,90 280,110 270,70 240,45',
    neighbors: ['satu_mare', 'bistrita', 'cluj', 'suceava'],
  },
  {
    id: 'suceava',
    name: 'Bucovina (Suceava)',
    shortName: 'SV',
    region: 'Nord-Est',
    labelX: 400,
    labelY: 70,
    polygon: '340,35 440,45 450,115 360,90 340,35',
    neighbors: ['maramures', 'botosani', 'neamt', 'bistrita'],
  },
  {
    id: 'botosani',
    name: 'Botoșani',
    shortName: 'BT',
    region: 'Nord-Est',
    labelX: 490,
    labelY: 75,
    polygon: '440,45 530,65 520,130 450,115 440,45',
    neighbors: ['suceava', 'iasi'],
  },
  // Moldova
  {
    id: 'iasi',
    name: 'Iași',
    shortName: 'IS',
    region: 'Moldova',
    labelX: 535,
    labelY: 145,
    polygon: '520,130 570,110 605,185 535,190 475,155 450,115 520,130',
    neighbors: ['botosani', 'suceava', 'neamt', 'vaslui'],
  },
  {
    id: 'neamt',
    name: 'Neamț & Bacău Nord',
    shortName: 'NT',
    region: 'Moldova',
    labelX: 470,
    labelY: 185,
    polygon: '450,115 475,155 535,190 515,235 440,215 450,115',
    neighbors: ['suceava', 'iasi', 'bacau', 'harghita'],
  },
  {
    id: 'vaslui',
    name: 'Vaslui & Bârlad',
    shortName: 'VS',
    region: 'Moldova',
    labelX: 575,
    labelY: 225,
    polygon: '535,190 605,185 625,260 560,270 515,235 535,190',
    neighbors: ['iasi', 'neamt', 'bacau', 'galati'],
  },
  {
    id: 'bacau',
    name: 'Bacău & Vrancea',
    shortName: 'BC',
    region: 'Moldova',
    labelX: 500,
    labelY: 265,
    polygon: '440,215 515,235 560,270 535,320 460,300 440,215',
    neighbors: ['neamt', 'vaslui', 'galati', 'buzau', 'brasov'],
  },
  {
    id: 'galati',
    name: 'Galați & Brăila',
    shortName: 'GL',
    region: 'Sud-Est',
    labelX: 595,
    labelY: 310,
    polygon: '560,270 625,260 640,310 670,305 605,375 560,350 535,320 560,270',
    neighbors: ['vaslui', 'bacau', 'buzau', 'tulcea', 'ialomita'],
  },
  // Dobrogea
  {
    id: 'tulcea',
    name: 'Tulcea (Delta Dunării)',
    shortName: 'TL',
    region: 'Dobrogea',
    labelX: 680,
    labelY: 345,
    polygon: '670,305 735,335 715,390 655,415 605,375 670,305',
    neighbors: ['galati', 'constanta', 'ialomita'],
  },
  {
    id: 'constanta',
    name: 'Constanța (Marea Neagră)',
    shortName: 'CT',
    region: 'Dobrogea',
    labelX: 655,
    labelY: 465,
    polygon: '655,415 715,390 685,460 670,520 575,495 595,435 655,415',
    neighbors: ['tulcea', 'calarasi', 'ialomita'],
  },
  // Vest & Banat
  {
    id: 'bihor',
    name: 'Bihor (Oradea)',
    shortName: 'BH',
    region: 'Vest',
    labelX: 135,
    labelY: 155,
    polygon: '160,95 210,120 195,185 140,200 110,155 160,95',
    neighbors: ['satu_mare', 'salaj', 'cluj', 'arad'],
  },
  {
    id: 'arad',
    name: 'Arad',
    shortName: 'AR',
    region: 'Vest',
    labelX: 130,
    labelY: 225,
    polygon: '110,155 140,200 195,185 185,245 90,215 110,155',
    neighbors: ['bihor', 'cluj', 'hunedoara', 'timis'],
  },
  {
    id: 'timis',
    name: 'Timiș (Timișoara)',
    shortName: 'TM',
    region: 'Banat',
    labelX: 110,
    labelY: 295,
    polygon: '90,215 185,245 195,305 165,340 85,340 70,275 90,215',
    neighbors: ['arad', 'hunedoara', 'caras'],
  },
  {
    id: 'caras',
    name: 'Caraș-Severin (Reșița)',
    shortName: 'CS',
    region: 'Banat',
    labelX: 135,
    labelY: 385,
    polygon: '85,340 165,340 195,305 185,385 145,440 120,395 85,340',
    neighbors: ['timis', 'hunedoara', 'gorj', 'mehedinti'],
  },
  // Transilvania
  {
    id: 'salaj',
    name: 'Sălaj & Bistrița',
    shortName: 'SJ',
    region: 'Transilvania',
    labelX: 255,
    labelY: 140,
    polygon: '210,120 270,70 280,110 360,90 340,155 255,165 210,120',
    neighbors: ['satu_mare', 'maramures', 'cluj'],
  },
  {
    id: 'cluj',
    name: 'Cluj (Cluj-Napoca)',
    shortName: 'CJ',
    region: 'Transilvania',
    labelX: 265,
    labelY: 195,
    polygon: '195,185 255,165 340,155 350,215 265,225 195,185',
    neighbors: ['bihor', 'salaj', 'mures', 'alba', 'arad'],
  },
  {
    id: 'mures',
    name: 'Mureș & Harghita',
    shortName: 'MS',
    region: 'Transilvania',
    labelX: 385,
    labelY: 200,
    polygon: '340,155 450,115 440,215 460,250 380,255 350,215 340,155',
    neighbors: ['cluj', 'suceava', 'neamt', 'bacau', 'brasov', 'sibiu'],
  },
  {
    id: 'hunedoara',
    name: 'Hunedoara & Alba',
    shortName: 'HD',
    region: 'Transilvania',
    labelX: 235,
    labelY: 265,
    polygon: '195,185 265,225 315,230 300,305 215,320 185,245 195,185',
    neighbors: ['arad', 'cluj', 'sibiu', 'gorj', 'caras', 'timis'],
  },
  {
    id: 'brasov',
    name: 'Brașov & Sibiu',
    shortName: 'BV',
    region: 'Transilvania',
    labelX: 345,
    labelY: 285,
    polygon: '315,230 380,255 460,250 435,315 375,310 290,315 300,305 315,230',
    neighbors: ['hunedoara', 'mures', 'bacau', 'buzau', 'prahova', 'arges', 'valcea'],
  },
  // Oltenia
  {
    id: 'mehedinti',
    name: 'Mehedinți & Gorj Vest',
    shortName: 'MH',
    region: 'Oltenia',
    labelX: 185,
    labelY: 435,
    polygon: '145,440 185,385 220,405 215,510 170,475 145,440',
    neighbors: ['caras', 'gorj', 'dolj'],
  },
  {
    id: 'dolj',
    name: 'Dolj & Gorj Est (Craiova)',
    shortName: 'DJ',
    region: 'Oltenia',
    labelX: 245,
    labelY: 445,
    polygon: '185,385 290,315 310,380 275,520 215,510 220,405 185,385',
    neighbors: ['mehedinti', 'hunedoara', 'brasov', 'olt'],
  },
  // Muntenia
  {
    id: 'arges',
    name: 'Argeș & Prahova',
    shortName: 'AG',
    region: 'Muntenia',
    labelX: 365,
    labelY: 375,
    polygon: '290,315 375,310 435,315 440,395 350,410 310,380 290,315',
    neighbors: ['brasov', 'dolj', 'olt', 'bucuresti', 'buzau'],
  },
  {
    id: 'olt',
    name: 'Olt & Teleorman (Dunăre)',
    shortName: 'OT',
    region: 'Muntenia',
    labelX: 325,
    labelY: 485,
    polygon: '310,380 350,410 425,435 385,545 335,535 275,520 310,380',
    neighbors: ['dolj', 'arges', 'bucuresti', 'calarasi'],
  },
  {
    id: 'bucuresti',
    name: 'București, Ilfov & Bărăgan',
    shortName: 'B',
    region: 'Muntenia',
    labelX: 475,
    labelY: 425,
    polygon: '435,315 460,300 535,320 560,350 575,495 520,515 425,435 350,410 440,395 435,315',
    neighbors: ['arges', 'olt', 'galati', 'tulcea', 'constanta'],
  },
];

/**
 * 29 teritorii disponibile în setul curent (6–10 jucători). Nu reprezintă toate județele României.
 */
export const ROMANIA_29_TERRITORIES: TerritoryDef[] = [
  ...ROMANIA_25_TERRITORIES,
  {
    id: 'maramures_nord',
    name: 'Sighetu Marmației',
    shortName: 'MM2',
    region: 'Nord',
    labelX: 310,
    labelY: 55,
    polygon: '280,45 340,35 360,75 295,75 280,45',
    neighbors: ['maramures', 'suceava'],
  },
  {
    id: 'buzau',
    name: 'Buzău',
    shortName: 'BZ',
    region: 'Muntenia',
    labelX: 495,
    labelY: 345,
    polygon: '435,315 470,295 535,320 495,375 440,360 435,315',
    neighbors: ['brasov', 'bacau', 'galati', 'bucuresti', 'arges'],
  },
  {
    id: 'calarasi',
    name: 'Călărași & Giurgiu',
    shortName: 'CL',
    region: 'Muntenia',
    labelX: 480,
    labelY: 490,
    polygon: '425,435 520,515 575,495 480,535 425,435',
    neighbors: ['olt', 'bucuresti', 'constanta'],
  },
  {
    id: 'harghita',
    name: 'Harghita & Covasna',
    shortName: 'HR',
    region: 'Transilvania',
    labelX: 425,
    labelY: 250,
    polygon: '410,215 460,210 470,285 425,295 410,215',
    neighbors: ['mures', 'bacau', 'brasov'],
  },
];

/**
 * Generates map territory state initialized for a match.
 * Scales dynamically based on player count!
 * - 2 players: 10 regions
 * - 3 players: 15 regions
 * - 4-5 players: 25 available definitions
 * - 6-10 players: 29 available definitions
 * NOTE: these are currently hand-drawn schematic polygons, not authoritative county-boundary GeoJSON.
 */
export function createMapForPlayerCount(playerCount: number): Record<string, any> {
  let defs = ROMANIA_15_TERRITORIES;

  if (playerCount <= 2) {
    defs = ROMANIA_10_TERRITORIES;
  } else if (playerCount === 3) {
    defs = ROMANIA_15_TERRITORIES;
  } else if (playerCount <= 5) {
    defs = ROMANIA_25_TERRITORIES;
  } else {
    defs = ROMANIA_29_TERRITORIES;
  }

  const validIds = new Set(defs.map(t => t.id));
  const neighborsById = new Map<string, Set<string>>();
  for (const t of defs) {
    neighborsById.set(t.id, new Set(t.neighbors.filter(id => validIds.has(id) && id !== t.id)));
  }
  // Some hand-maintained source lists were one-sided. Normalize graph edges once here.
  for (const [id, neighbors] of neighborsById.entries()) {
    for (const neighborId of neighbors) neighborsById.get(neighborId)?.add(id);
  }

  const map: Record<string, any> = {};
  for (const t of defs) {
    map[t.id] = {
      id: t.id,
      name: t.name,
      shortName: t.shortName,
      region: t.region,
      svgPath: t.polygon,
      labelX: t.labelX,
      labelY: t.labelY,
      points: 0, // Unclaimed territories show NO score number until taken!
      ownerId: null,
      isBase: false,
      basePlayerName: undefined,
      castleTowers: 3,
      defensiveBonus: 0,
      neighbors: Array.from(neighborsById.get(t.id) || []),
    };
  }
  return map;
}
