# CONQUIZ – Trivia Strategy România

Joc multiplayer de cultură generală cu hartă strategică, alegerea bazelor, cucerire, alocarea teritoriilor libere și război.

## Tehnologii

- React + TypeScript + Vite
- Node.js + Express
- Socket.IO
- JSON file storage pentru datele locale ale prototipului

## Instalare locală

```bash
npm install
cp .env.example .env
```

Completează `.env` cu valori proprii:

- `JWT_SECRET`: minimum 32 de caractere aleatorii; în producție nu folosi placeholder.
- `ADMIN_EMAIL`: adresa administratorului inițial.
- `ADMIN_USERNAME`: numele administratorului inițial.
- `ADMIN_PASSWORD`: 20–128 de caractere aleatorii.

Apoi:

```bash
npm run dev
```

Pentru build:

```bash
npm run build
```

Pentru verificarea tipurilor:

```bash
npm run lint
```

## Reguli curente

- Bază: 1000 puncte.
- Cucerire: 200 puncte.
- Alocare prin estimare numerică: 300 puncte.
- Cucerire în război: 400 puncte.
- Apărare corectă când atacatorul greșește: +100 bonus defensiv.
- 15 secunde pentru selecții, 12 secunde pentru grilă și 10 secunde pentru estimări numerice.
- Cameră: între 2 și 10 jucători; gazda alege categoriile, nu durata rundelor sau punctajul.

## Limitări cunoscute

- Harta actuală din `server/romaniaMapData.ts` este încă schematică, desenată manual; nu este încă GeoJSON oficial.
- Banca livrată conține 100 de întrebări, nu mii.
- Înainte de publicare trebuie rulate build-ul, typecheck-ul și teste end-to-end multiplayer.

Vezi `AUDIT-2026-11-08.md` pentru constatările auditului, modificările aplicate și limitele testării.
